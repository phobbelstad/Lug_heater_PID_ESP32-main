/*
LUG heater 
ESP32 with PID controlling pwm
*/

//======================#include libraries=========================
#include <WiFi.h>
extern "C" {
  #include "freertos/FreeRTOS.h"
  #include "freertos/timers.h"
}
#include <AsyncMqttClient.h>
//temperature
#include <OneWire.h>
#include <DallasTemperature.h>
#include <PID_v1.h>
#include <SparkFun_MCP9600.h>
//STRING
#include <cstring>
#include <string.h>
#include <stdio.h>
#include <SPI.h>
//OLED
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>


//======================WIFI=========================
#define WIFI_SSID "EaseeTest"
#define WIFI_PASSWORD "TestingEasee"

//======================MQTT=========================
#define MQTT_HOST IPAddress(10, 90, 6, 12)
#define MQTT_PORT 1883
//MQTT TOPICS
#define MQTT_PUB_TEMP "QA/Lug_Heater/temperature_act"
#define MQTT_PUB_PIDACTIVE "QA/Lug_Heater/PID_values//PID_ACTIVATE"
#define MQTT_PUB_RUN "QA/Lug_Heater/PID_values/RUN"
#define MQTT_PUB_SETPOINT "QA/Lug_Heater/PID_values/PID_SETPOINT"
#define MQTT_PUB_KP "QA/Lug_Heater/PID_values/PID_KP"
#define MQTT_PUB_KI "QA/Lug_Heater/PID_values/PID_KI"
#define MQTT_PUB_KD "QA/Lug_Heater/PID_values/PID_Kd"
#define MQTT_PUB_RESTRICT "QA/Lug_Heater/PID_values/PID_RESTRICT"
#define MQTT_PUB_PWM1 "QA/Lug_Heater/PID_output/PID_OUTPUT1"
#define MQTT_PUB_PWM2 "QA/Lug_Heater/PID_output/PID_OUTPUT2"
#define MQTT_PUB_PWM3 "QA/Lug_Heater/PID_output/PID_OUTPUT3"
#define MQTT_PUB_PWM4 "QA/Lug_Heater/PID_output/PID_OUTPUT4"
#define MQTT_PUB_PWM5 "QA/Lug_Heater/PID_output/PID_OUTPUT5"
#define MQTT_PUB_SETPOINT1 "QA/Lug_Heater/PID_loop/PID_SETPOINT1"
#define MQTT_PUB_SETPOINT2 "QA/Lug_Heater/PID_loop/PID_SETPOINT2"
#define MQTT_PUB_SETPOINT3 "QA/Lug_Heater/PID_loop/PID_SETPOINT3"
#define MQTT_PUB_SETPOINT4 "QA/Lug_Heater/PID_loop/PID_SETPOINT4"
#define MQTT_PUB_SETPOINT5 "QA/Lug_Heater/PID_loop/PID_SETPOINT5"
#define MQTT_PUB_INPUT1 "QA/Lug_Heater/PID_loop/PID_INPUT1"
#define MQTT_PUB_INPUT2 "QA/Lug_Heater/PID_loop/PID_INPUT2"
#define MQTT_PUB_INPUT3 "QA/Lug_Heater/PID_loop/PID_INPUT3"
#define MQTT_PUB_INPUT4 "QA/Lug_Heater/PID_loop/PID_INPUT4"
#define MQTT_PUB_INPUT5 "QA/Lug_Heater/PID_loop/PID_INPUT5"
#define MQTT_PUB_DEBUG "QA/Lug_Heater/PID_control/debug"
#define MQTT_PUB_DEBUG2 "QA/Lug_Heater/PID_control/debug2"
#define MQTT_SUB_CMND "QA/Lug_Heater/PID_control/subscribe"

//======================Define pins=========================
//OLED pins
#define OLED_SDA 4
#define OLED_SCL 15 
#define OLED_RST 16

// GPIO where the DS18B20 is connected to
const int oneWireBus = 13;      

//PWM
#define PWM_out1 21
#define PWM_out2 22
#define PWM_out3 23
#define PWM_out4 25
#define PWM_out5 27

// assign LED pins
int ledgreen = 40;
int ledylw = 39;
int ledred = 38;


//======================constants=========================
//OLED
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels

//======================variables=========================

//Control
bool run = false;

//deliminiter 
int findDelimiter(String text, char delimiter) {
  int i;
  for (i = 0; i < text.length(); i++) {
    if(text[i] == delimiter) {
      return(i);
    }
  }
  return(-1);
}

//packet counter
int counter = 0;

//wifi
String wifi_status = "NULL";

//Timer
unsigned int countdownInSeconds = 240*1000;  
int countdownNow= 1;
bool countdownRunning = false;

//Temperature
float temperature_value;

//PID
double Setpoint = 0;
double Setpoint1= 0;
double Setpoint2 = 0;
double Setpoint3 = 0;
double Setpoint4 = 0;
double Setpoint5 = 0;
double Input,Input2, Input3, Input4, Input5;
double Output, Output2, Output3, Output4, Output5;
double Kp=1.5, Ki=0.05, Kd=0.1;
PID myPID(&Input, &Output, &Setpoint1, Kp, Ki, Kd, DIRECT);
PID myPID2(&Input2, &Output2, &Setpoint2, Kp, Ki, Kd, DIRECT);
PID myPID3(&Input3, &Output3, &Setpoint3, Kp, Ki, Kd, DIRECT);
PID myPID4(&Input4, &Output4, &Setpoint4, Kp, Ki, Kd, DIRECT);
PID myPID5(&Input5, &Output5, &Setpoint5, Kp, Ki, Kd, DIRECT);
bool PID_active = false;

int restrict_high = 15;
double offset1 = 0;
double offset2 = 0;
double offset3 = 0;
double offset4 = 0;
double offset5 = 0;


//MQTT
AsyncMqttClient mqttClient;
TimerHandle_t mqttReconnectTimer;
TimerHandle_t wifiReconnectTimer;

unsigned long previousMillis = 0;   // Stores last time temperature was published
const long interval = 1000;        // Interval at which to publish sensor readings

//======================Initialise libraries=========================
// DISPLAY
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RST);   // Setup a oneWire instance to communicate with any OneWire devices
//TEMPERATURE
OneWire oneWire(oneWireBus);                                              // Pass our oneWire reference to Dallas Temperature sensor 
DallasTemperature sensors(&oneWire);
MCP9600 tempSensor;
Thermocouple_Type type = TYPE_K;

//++++++++++++++++++++++WIFI & MQTT+++++++++++++++++++++++++++++++++++++++
void connectToWifi() {
  Serial.println("Connecting to Wi-Fi...");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

void connectToMqtt() {
  Serial.println("Connecting to MQTT...");
  mqttClient.connect();
}

void WiFiEvent(WiFiEvent_t event) {
  Serial.printf("[WiFi-event] event: %d\n", event);
  switch(event) {
    case SYSTEM_EVENT_STA_GOT_IP:
      Serial.println("WiFi connected");
      Serial.println("IP address: ");
      Serial.println(WiFi.localIP());
      digitalWrite(ledred, LOW);
      digitalWrite(ledgreen, HIGH);
      connectToMqtt();
      wifi_status = "Wifi OK";
      break;
    case SYSTEM_EVENT_STA_DISCONNECTED:
      Serial.println("WiFi lost connection");
      xTimerStop(mqttReconnectTimer, 0); // ensure we don't reconnect to MQTT while reconnecting to Wi-Fi
      xTimerStart(wifiReconnectTimer, 0);
      digitalWrite(ledgreen, LOW);
      digitalWrite(ledred, HIGH);
      wifi_status = "Wifi lost";
      break;
  }
}

void onMqttConnect(bool sessionPresent) {
  uint16_t packetIdSub = mqttClient.subscribe(MQTT_SUB_CMND, 2);
  Serial.println("Connected to MQTT.");
  Serial.print("Session present: ");
  Serial.println(sessionPresent);
  digitalWrite(ledylw, HIGH);
}

void onMqttDisconnect(AsyncMqttClientDisconnectReason reason) {
  Serial.println("Disconnected from MQTT.");
  if (WiFi.isConnected()) {
    xTimerStart(mqttReconnectTimer, 0);
    digitalWrite(ledylw, LOW);
  }
}

/*void onMqttSubscribe(uint16_t packetId, uint8_t qos) {
  Serial.println("Subscribe acknowledged.");
  Serial.print("  packetId: ");
  Serial.println(packetId);
  Serial.print("  qos: ");
  Serial.println(qos);
}
void onMqttUnsubscribe(uint16_t packetId) {
  Serial.println("Unsubscribe acknowledged.");
  Serial.print("  packetId: ");
  Serial.println(packetId);
}*/

void onMqttPublish(uint16_t packetId) {
  // Serial.println("Publish acknowledged.");
  // Serial.print("  packetId: ");
  // Serial.println(packetId);
}

void onMqttMessage(char* topic, char* payload, AsyncMqttClientMessageProperties properties, size_t len, size_t index, size_t total) {
  Serial.println("Publish received.");
  Serial.print("  topic: ");
  Serial.println(topic);
  Serial.print("  qos: ");
  Serial.println(properties.qos);
  Serial.print("  dup: ");
  Serial.println(properties.dup);
  Serial.print("  retain: ");
  Serial.println(properties.retain);
  Serial.print("  len: ");
  Serial.println(len);
  Serial.print("  index: ");
  Serial.println(index);
  Serial.print("  total: ");
  Serial.println(total);

  String message = "";
  for(int i = 0; i < len; i++) {
    message += (char) payload[i];
  }
  message.trim();
  int argPos = findDelimiter(message, '=');
  String command = message.substring(0, argPos);
  String arg = message.substring(argPos+1);
  uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG2, 1, true, String(arg).c_str()); 
  Serial.print("command recieved: ");
  Serial.println(arg);

  if(command == "kp"){
    Kp = arg.toDouble();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("Kp value changed..").c_str());
    Serial.println(arg.toDouble());}

  else if(command == "ki"){
    Ki = arg.toDouble();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("Ki value changed..").c_str());
    Serial.println(arg.toDouble());}
    
  else if(command == "kd"){
    Kd = arg.toDouble();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("Kd value changed..").c_str());
    Serial.println(arg.toDouble());}
    
  else if(command == "setpoint"){
    Setpoint = arg.toDouble();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("Setpoint value changed..").c_str());
    Serial.println(arg.toDouble());
      Setpoint1= Setpoint - offset1;
      Setpoint2 = Setpoint - offset2;
      Setpoint3 = Setpoint - offset3;
      Setpoint4 = Setpoint;
      Setpoint5 = Setpoint - offset5;}

  else if(command == "restrict"){
    restrict_high = arg.toInt();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("Restrict_high value changed..").c_str());
    Serial.println(arg.toInt());}

  else if(command == "offset1"){
    offset1 = arg.toDouble();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("offset1 value changed..").c_str());
    Serial.println(arg.toDouble());
    Setpoint1= Setpoint - offset1;}

  else if(command == "offset2"){
    offset2 = arg.toDouble();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("offset2 value changed..").c_str());
    Serial.println(arg.toDouble());
    Setpoint2= Setpoint - offset2;}

  else if(command == "offset3"){
    offset3 = arg.toDouble();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("offset3 value changed..").c_str());
    Serial.println(arg.toDouble());
    Setpoint3= Setpoint - offset3;}

  // else if(command == "offset4"){
  //   offset4 = arg.toDouble();
  //   uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("offset4 value changed..").c_str());
  //   Serial.println(arg.toDouble());}

  else if(command == "offset5"){
    offset5 = arg.toDouble();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("offset5 value changed..").c_str());
    Serial.println(arg.toDouble());
    Setpoint5= Setpoint - offset5;}

  else if(command == "countdown"){
    countdownInSeconds= arg.toInt();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("countdown value changed..").c_str());
    Serial.println(arg.toInt());}

  else if(command == "run"){
    run = arg.toInt();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("Run mode changed to.. ").c_str());
    Serial.println(arg.toInt());}
    
  else if(command == "pidactive"){
    PID_active = arg.toInt();
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("PID mode changed to.. ").c_str());
    Serial.println(arg.toInt());}
  
  else{
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_DEBUG, 1, true, String("Unknown command, please try again...").c_str());
  }

  
     

}

//+++++++++++++++++++++++ MAIN +++++++++++++++++++++++++++++++++++++++++++

void setup() {
  // Start the DS18B20 sensor
  sensors.begin();

  // Start Thermocouple sensor(I2C) and perform checks
  Wire.begin(OLED_SDA, OLED_SCL);
  Wire.setClock(100000);
  tempSensor.begin();       // Uses the default address (0x60) for SparkFun Thermocouple Amplifier
      //check if the sensor is connected
    if(tempSensor.isConnected()){
        Serial.println("Device will acknowledge!");
    }
    else {
        Serial.println("Device did not acknowledge! Freezing.");
    }
    //check if the Device ID is correct
    if(tempSensor.checkDeviceID()){
        Serial.println("Device ID is correct!");        
    }
    else {
        Serial.println("Device ID is not correct! Freezing.");
    }

    Serial.println("Setting Thermocouple Type!");
    tempSensor.setThermocoupleType(type);

    //make sure the type was set correctly!
    if(tempSensor.getThermocoupleType() == type){
        Serial.println("Thermocouple Type set sucessfully!");
    }

    else{
        Serial.println("Setting Thermocouple Type failed!");
    }
  
  // start Serial
  Serial.begin(115200);
  Serial.println();
  Serial.println();

  // PWM output

  pinMode(PWM_out1,OUTPUT);
  pinMode(PWM_out2,OUTPUT);
  pinMode(PWM_out3,OUTPUT);
  pinMode(PWM_out4,OUTPUT);
  pinMode(PWM_out5,OUTPUT);
  
  mqttReconnectTimer = xTimerCreate("mqttTimer", pdMS_TO_TICKS(2000), pdFALSE, (void*)0, reinterpret_cast<TimerCallbackFunction_t>(connectToMqtt));
  wifiReconnectTimer = xTimerCreate("wifiTimer", pdMS_TO_TICKS(3000), pdFALSE, (void*)0, reinterpret_cast<TimerCallbackFunction_t>(connectToWifi));
  WiFi.onEvent(WiFiEvent);
  WiFi.setSleep(false);

  mqttClient.onConnect(onMqttConnect);
  mqttClient.onDisconnect(onMqttDisconnect);
  //mqttClient.onSubscribe(onMqttSubscribe);
  //mqttClient.onUnsubscribe(onMqttUnsubscribe);
  mqttClient.onMessage(onMqttMessage);
  mqttClient.onPublish(onMqttPublish);
  mqttClient.setServer(MQTT_HOST, MQTT_PORT);
  // If your broker requires authentication (username and password), set them below
  //mqttClient.setCredentials("REPlACE_WITH_YOUR_USER", "REPLACE_WITH_YOUR_PASSWORD");
  connectToWifi();

  //---PID-----
  Input = temperature_value; //initialize the variables we're linked to
  myPID.SetMode(AUTOMATIC);   //turn the PID1 on
  myPID2.SetMode(AUTOMATIC);   //turn the PID2 on
  myPID3.SetMode(AUTOMATIC);   //turn the PID3 on
  myPID4.SetMode(AUTOMATIC);   //turn the PID4 on
  myPID5.SetMode(AUTOMATIC);   //turn the PID5 on

  int sample_time = 1000;

  myPID.SetSampleTime(sample_time);
  myPID2.SetSampleTime(sample_time);
  myPID3.SetSampleTime(sample_time);
  myPID4.SetSampleTime(sample_time);
  myPID5.SetSampleTime(sample_time);

    //initialize Serial Monitor
  Serial.begin(115200);

  //reset OLED display via software
  pinMode(OLED_RST, OUTPUT);
  digitalWrite(OLED_RST, LOW);
  delay(20);
  digitalWrite(OLED_RST, HIGH);

  //initialize OLED
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3c, false, false)) { // Address 0x3C for 128x32
    Serial.println(F("SSD1306 allocation failed"));
    for(;;); // Don't proceed, loop forever
  }
  
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextSize(1);
  display.setCursor(0,0);
  display.print("LORA SENDER ");
  display.display();
}

void loop() {
  // Temperature accuering 
  unsigned long currentMillis = millis();                                         // Every X number of seconds (interval = 10 seconds) it publishes a new MQTT message
  sensors.requestTemperatures();                                                  // New temperature readings, 

// if (sensors.getTempCByIndex(0) == -127)                                          // if condition to automatic change from temp sensor to thermocoupler accordingly..
// {
   temperature_value = tempSensor.getThermocoupleTemp();                            // Temperature in Celsius degrees                                             // send temp to PID controller
    Input = temperature_value;                                             // send temp to PID controller1
    Input2 = temperature_value;                                             // send temp to PID controller2
    Input3 = temperature_value;                                             // send temp to PID controller3
    Input4 = temperature_value;                                             // send temp to PID controller4
    Input5 = temperature_value;                                             // send temp to PID controller5
   delay(20);
  // }
  //  else
  //  {
  //   temperature_value = sensors.getTempCByIndex(0);                                 // Temperature in Celsius degrees
  //   Input = sensors.getTempCByIndex(0);                                             // send temp to PID controller1
  //   Input2 = sensors.getTempCByIndex(0);                                             // send temp to PID controller2
  //   Input3 = sensors.getTempCByIndex(0);                                             // send temp to PID controller3
  //   Input4 = sensors.getTempCByIndex(0);                                             // send temp to PID controller4
  //   Input5 = sensors.getTempCByIndex(0);                                             // send temp to PID controller5
  //  }

  // PID loop

    myPID.SetOutputLimits(0, restrict_high);                                      // restrict PWM max value
    myPID.SetTunings(Kp, Ki, Kd);                                                 // insert and use indexes from variabled
    myPID.Compute();                                                              // PID calculates hos to react
    double pwm_percent = (Output/restrict_high)*100;
    
    myPID2.SetOutputLimits(0, restrict_high);                                      // restrict PWM max value
    myPID2.SetTunings(Kp, Ki, Kd);                                                 // insert and use indexes from variabled
    myPID2.Compute();
    
    myPID3.SetOutputLimits(0, restrict_high);                                      // restrict PWM max value
    myPID3.SetTunings(Kp, Ki, Kd);                                                 // insert and use indexes from variabled
    myPID3.Compute();    
    
    myPID4.SetOutputLimits(0, restrict_high);                                      // restrict PWM max value
    myPID4.SetTunings(Kp, Ki, Kd);                                                 // insert and use indexes from variabled
    myPID4.Compute();    

    myPID5.SetOutputLimits(0, restrict_high);                                      // restrict PWM max value
    myPID5.SetTunings(Kp, Ki, Kd);                                                 // insert and use indexes from variabled
    myPID5.Compute();    

  // PWM
  if (run == 1)
  {
    if (PID_active == 1)
    {
    analogWrite(PWM_out1,Output);
    analogWrite(PWM_out2,Output2);
    analogWrite(PWM_out3,Output3);
    analogWrite(PWM_out4,Output4);
    analogWrite(PWM_out5,Output5);  
    }
    else
    {
      Output = restrict_high;
      Output2 = restrict_high;
      Output3 = restrict_high;
      Output4 = restrict_high;
      Output5 = restrict_high;

    analogWrite(PWM_out1,Output);
    analogWrite(PWM_out2,Output2);
    analogWrite(PWM_out3,Output3);
    analogWrite(PWM_out4,Output4);
    analogWrite(PWM_out5,Output5);  
    }
    
  }

  else
  {
    Output = 0;
    Output2 = 0;
    Output3 = 0;
    Output4 = 0;
    Output5 = 0;

    analogWrite(PWM_out1,Output);
    analogWrite(PWM_out2,Output2);
    analogWrite(PWM_out3,Output3);
    analogWrite(PWM_out4,Output4);
    analogWrite(PWM_out5,Output5); 
  }
  
                                               // adjust PWM with Output from PID
  
  //write OLED
    display.clearDisplay();
    display.setTextColor(WHITE);
    display.setTextSize(3);
    display.setCursor(0,0);
    display.print(temperature_value);    //write temperature
    display.setTextSize(2);
    display.print("o"); 
    display.setTextSize(3);
    display.print("C");

    display.display();

    display.setCursor(0,30);
    display.setTextSize(2);
    display.print(Setpoint, 0);              // write PID setpoint
    display.setTextSize(1);
    display.print("o");
    display.setTextSize(2);
    display.print("C");


    display.setTextSize(2);
    display.print(" ");
    display.print(pwm_percent, 1);                // write Output(PWM)
    display.print("%");
    display.display();

    display.setCursor(0,50);
    display.setTextSize(2);
    display.print(wifi_status);           //write wifi status
    display.display();
  //MQTT

  if (currentMillis - previousMillis >= interval) 
  {
    previousMillis = currentMillis;  // Save the last time a new reading was published

    // Publish an MQTT message on topic
    uint16_t packetIdPub1 = mqttClient.publish(MQTT_PUB_TEMP, 1, true, String(temperature_value).c_str());
    uint16_t packetIdPub2 = mqttClient.publish(MQTT_PUB_SETPOINT, 1, true, String(Setpoint).c_str());
    uint16_t packetIdPub3 = mqttClient.publish(MQTT_PUB_KP, 1, true, String(myPID.GetKp()).c_str());      
    uint16_t packetIdPub4 = mqttClient.publish(MQTT_PUB_KI, 1, true, String(myPID.GetKi()).c_str());  
    uint16_t packetIdPub5 = mqttClient.publish(MQTT_PUB_KD, 1, true, String(myPID.GetKd()).c_str());          
    uint16_t packetIdPub6 = mqttClient.publish(MQTT_PUB_PWM1, 1, true, String(Output).c_str());
    uint16_t packetIdPub7 = mqttClient.publish(MQTT_PUB_PWM2, 1, true, String(Output2).c_str());
    uint16_t packetIdPub8 = mqttClient.publish(MQTT_PUB_PWM3, 1, true, String(Output3).c_str());
    uint16_t packetIdPub9 = mqttClient.publish(MQTT_PUB_PWM4, 1, true, String(Output4).c_str());
    uint16_t packetIdPub10 = mqttClient.publish(MQTT_PUB_PWM5, 1, true, String(Output5).c_str());
    uint16_t packetIdPub11 = mqttClient.publish(MQTT_PUB_RESTRICT, 1, true, String(restrict_high).c_str());
    uint16_t packetIdPub12 = mqttClient.publish(MQTT_PUB_SETPOINT1, 1, true, String(Setpoint1).c_str());
    uint16_t packetIdPub13 = mqttClient.publish(MQTT_PUB_INPUT1, 1, true, String(Input).c_str());
    uint16_t packetIdPub14 = mqttClient.publish(MQTT_PUB_SETPOINT2, 1, true, String(Setpoint2).c_str());
    uint16_t packetIdPub15 = mqttClient.publish(MQTT_PUB_INPUT2, 1, true, String(Input2).c_str());
    uint16_t packetIdPub16 = mqttClient.publish(MQTT_PUB_SETPOINT3, 1, true, String(Setpoint3).c_str());
    uint16_t packetIdPub17 = mqttClient.publish(MQTT_PUB_INPUT3, 1, true, String(Input3).c_str());   
    uint16_t packetIdPub18 = mqttClient.publish(MQTT_PUB_SETPOINT4, 1, true, String(Setpoint4).c_str());
    uint16_t packetIdPub19 = mqttClient.publish(MQTT_PUB_INPUT4, 1, true, String(Input4).c_str());
    uint16_t packetIdPub20 = mqttClient.publish(MQTT_PUB_SETPOINT5, 1, true, String(Setpoint5).c_str());
    uint16_t packetIdPub21 = mqttClient.publish(MQTT_PUB_INPUT5, 1, true, String(Input5).c_str());
    uint16_t packetIdPub22 = mqttClient.publish(MQTT_PUB_PIDACTIVE, 1, true, String(PID_active).c_str());
    uint16_t packetIdPub23 = mqttClient.publish(MQTT_PUB_RUN, 1, true, String(run).c_str());
                    

    Serial.printf("Message: %.2f /n", temperature_value);



  }


}